# nmftools

Implementation of NMF (Non-negative Matrix Factorization) and extension of NMF

* NMF (Basic NMF)
* SSNMF (Semi-Supervised NMF)
